﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoDAI_1
{
    class Evento
    {
        public char idDep;
        public string fecha;
        public string hora;
        public string lugar;
        public string descripcion;
        public Evento()
        {

        }//builder
        public Evento(string desc)
        {

        }//builder
    }//class
}//namespace
